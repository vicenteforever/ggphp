
Test the class with the example script:

- Create a directory on your webserver and upload the complete example directory and files
- Upload the class (PHP4 or PHP5 version) to the 'inc' directory
- Open the example.php page in your browser to see the direct output from the class
- Open the photo.php page to see a dynamically created thumbnail on a html page







