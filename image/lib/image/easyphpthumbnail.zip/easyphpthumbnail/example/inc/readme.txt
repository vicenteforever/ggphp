
Copy the class to this directory, choose PHP4 or PHP5







